var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_20260129_104353_00_004",
      "name": "IMG_20260129_104353_00_004",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1472,
      "initialViewParameters": {
        "yaw": 0.8887753575540351,
        "pitch": 0.09022832768482658,
        "fov": 1.3365071038314758
      },
      "linkHotspots": [
        {
          "yaw": 0.6436994108770353,
          "pitch": 0.19922152860852016,
          "rotation": 1.5707963267948966,
          "target": "0-img_20260129_104353_00_004"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-img_20260128_100255_00_0031",
      "name": "IMG_20260128_100255_00_003(1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1472,
      "initialViewParameters": {
        "yaw": -1.2242074989160194,
        "pitch": 0.6577440023842716,
        "fov": 1.3365071038314758
      },
      "linkHotspots": [
        {
          "yaw": 0.45921569561778064,
          "pitch": 0.07598035698056194,
          "rotation": 6.283185307179586,
          "target": "1-img_20260128_100255_00_0031"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -1.2242074989160194,
          "pitch": 0.6577440023842716,
          "title": "Title",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
